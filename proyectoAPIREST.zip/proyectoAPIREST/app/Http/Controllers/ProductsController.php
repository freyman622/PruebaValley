<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Response;


class ProductsController extends Controller
{
    public function index() {

        $products = Product::all();
         return response()->json([
            'status' => 200,
            'products' => $products, 
         ]);
        
        //return Product::all();
        //return view('products.index', compact('products'));
    }

    public function create(){
        
        return view('products.create');
    }

    public function store(Request $request){
        
        $product = new Product();

        $product->title = $request->title;
        $product->country = $request->country;
        $product->price = $request->price;

        $product->save();

        return response()->json([
            'status' => 200,
            'message' => 'Producto Creado con Exito', 
         ]);
        //return redirect()->route('products.index');

    }
        public function edit($id){

            $product = Product::find($id);

            return view('products.edit', compact('product'));

        }

        //public function update(Request $request, $id){
            
        public function update(Request $request, $id){
            
            $product = Product::find($id);
            if($product)
            {
                $product->title = $request->title;
                $product->country = $request->country;
                $product->price = $request->price;
                $product->update();

                return response()->json([
                    'status'=>200,
                    'product'=>'Producto Actualizado con Exito'
                ], 200);
            }
            else
            {
                return response()->json([
                    'status'=>404,
                    'product'=>'Id no Existe'
                ], 404);

            }

            //$product->update($request->all());
            //$product->save();
            //return redirect()->route('products.index');
           // return $product;
        }

        //public function destroy(Request $request) {

        public function delete($id) {


            $product = Product::find($id);
            if($product)
            {
                $product->delete();
                return response()->json([
                    'status'=>200,
                    'product'=>'Producto Eliminado Exitosamente'
                ], 200);
                
            }
            else
            {
                return response()->json([
                    'status'=>404,
                    'product'=>'Producto No Existe'

                ], 404);

            }


            
            $product = Product::destroy($request->$id);

            //$product->delete();

            //return redirect()->route('products.index');
        }

}
