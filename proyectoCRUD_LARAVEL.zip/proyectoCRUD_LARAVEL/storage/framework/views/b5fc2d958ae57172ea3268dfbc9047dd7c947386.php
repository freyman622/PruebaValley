

<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>

<div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">

<table class="table-fixed w-full">
    <thead>
    <tr class="bg-blue-500 text-white">
      <th class="w-20 py-4 ...">ID</th>  
      <th class="w-1/8 py-4 ...">Title</th>  
      <th class="w-1/16 py-4 ...">Country</th>  
      <th class="w-1/16 py-4 ...">Price</th>  
      <th class="w-1/16 py-4 ...">Created</th>  
      <th class="w-1/16 py-4 ...">Updated</th>  
      <th class="w-28 py-4 ...">Actions</th>  
    </tr>
</thead>
<tbody>
  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

  <tr>
    <td class="py-3 px-6"><?php echo e($row->id); ?></td>  
    <td class="p-3"><?php echo e($row->title); ?></td> 
    <td class="p-3"><?php echo e($row->country); ?></td> 
    <td class="p-3"><?php echo e($row->price); ?></td> 
    <td class="p-3 text-center"><?php echo e($row->created_at); ?></td>  
    <td class="p-3 text-center"><?php echo e($row->updated_at); ?></td>  
    <td class="p-3 flex justify-center">
      <form action="<?php echo e(route('products.destroy', $row->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('delete'); ?>
        <button class="bg-red-500 text-white px-3 py-1 rounded-sm mx-1">
        <i class="fas fa-trash"></i>D</button>
      </form>
        <a href="<?php echo e(route('products.edit', $row->id)); ?>" class="bg-green-500
            text-white px-3 py-1 rounded-sm"><i class="fas fa-pen"></i>E</a>
    </td> 
    </tr>  

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </tbody>
  </table>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectocrudlaravel\resources\views/products/index.blade.php ENDPATH**/ ?>