

<?php $__env->startSection('title', 'Create'); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('products.store')); ?>" method="POST"
    class="bg-white w-1/3 p-4 border-gray-100 shadow-xl rounded-lg">
    <?php echo csrf_field(); ?>
    
    <h2 class="text-2x1 text-center py-4 mb-4 font-semibold">Create Products</h2>

    <input class="my-2 w-full bg-gray-200 p-2 text-lg rounded placeholder-gray-900"
    placeholder="Title" name="title">

    <input class="my-2 w-full bg-gray-200 p-2 text-lg rounded placeholder-gray-900"
    placeholder="Country" name="country">

    <input class="my-2 w-full bg-gray-200 p-2 text-lg rounded placeholder-gray-900"
    placeholder="Price" name="price">

    <button type="submit" class="my-3 w-full bg-blue-500 p-2 font-semibold
    rounded text-white hover:bg-blue-600">Send</button>

</form>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyecto\resources\views/products/create.blade.php ENDPATH**/ ?>