

<?php $__env->startSection('title', 'Edit'); ?>

<?php $__env->startSection('content'); ?>

<form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST"
    class="bg-white w-1/3 p-4 border-gray-100 shadow-xl rounded-lg">
    <?php echo csrf_field(); ?>
    <?php echo method_field('put'); ?>
    <h2 class="text-2x1 text-center py-4 mb-4 font-semibold">
        Edit Product <?php echo e($product->id); ?>

    </h2>

    <input class="my-2 w-full bg-gray-200 p-2 text-lg rounded placeholder-gray-900"
    placeholder="Title" name="title" value="<?php echo e($product->title); ?>">

    <input class="my-2 w-full bg-gray-200 p-2 text-lg rounded placeholder-gray-900"
    placeholder="Country" name="country" value="<?php echo e($product->country); ?>">

    <input class="my-2 w-full bg-gray-200 p-2 text-lg rounded placeholder-gray-900"
    placeholder="Price" name="price" value="<?php echo e($product->price); ?>">

    <button type="submit" class="my-3 w-full bg-green-500 p-2 font-semibold
    rounded text-white hover:bg-green-600">Send</button>

</form>    

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\proyectocrudlaravel\resources\views/products/edit.blade.php ENDPATH**/ ?>